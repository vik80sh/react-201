import {connect} from 'react-redux';
import React, { Component, Fragment } from 'react';
import { getAllFlights } from '../../actions/flight.actions'
import FlightCard from '../../flight/components/flightCard';
import './admin-flights.css';
import {Link} from "react-router-dom";
import AdminNavBar from './admin-nav-bar';
class AdminFlights extends Component{
    constructor(props){
        super(props);
        this.state = {
            navBarClass: ''
        };
    }
    componentDidMount(){
        this.props.getAllFlights();
    }
    onNavBarHandler = (className) => {
        this.setState({
            navBarClass: className
        })
    }
    render(){
        let navClass = `admin-landing-page-1 ${this.state.navBarClass}`;
        let allData = this.props && this.props.allFlightData ? this.props.allFlightData : []; 
    return(
            <div >
              <div className="topnav">
                 <Link to="" className="active">Admin</Link>
                 <Link to="/admin">Dashboard</Link>
                 <Link to ="/">Home</Link>
               
              </div>
           
            {/* <AdminNavBar onNavBarHandler = {this.onNavBarHandler} /> */}
           
            <div className = "admin-landing-page-2">
            <div>
            {allData.map((post,key) => {
                return (
                    <Fragment key = {key}>
                    <div key={'div1' +key} className="card-parent col-sm-6 col-md-6 col-lg-6 col-xl-6" style={{padding:"60px 20px"}}>
                    <FlightCard role="admin_dashboard" flightData={post}/>
                 </div>
                 {/* <div key={'div2' +key} className="d-block d-md-none" >
                 <FlightCard role="admin_dashboard" flightData={post}/>
              </div> */}
              </Fragment>
                )
            })
        }
            </div>
            </div>
            </div>
           
    )
    
}
}
const mapStateToProps  = state => {
    return {
        allFlightData: state.flight.allFlights
    };
}
export default connect(mapStateToProps, {getAllFlights})(AdminFlights);