import React,{ Component } from "react";
import CardView from "../../shared/ui-components/cardview";
import "./admin-dashboard.scss";
import Paper from '@material-ui/core/Paper';

  import {
    Chart,
    BarSeries,
    Title,
    ArgumentAxis,
    ValueAxis,
  } from '@devexpress/dx-react-chart-material-ui';
  
  import { Animation } from '@devexpress/dx-react-chart';


  const data = [
    { region: 'Normal', val: 50 },
    { region: 'Handicapped', val: 20 },
    { region: 'Infants', val: 10 },
  ];
class AdminDashboard extends Component {
    constructor(props){
        super(props);
        this.state = {
            data,
          };
    }
   
    render(){
        const { data: chartData } = this.state;
        return(
            <div>
            <div className="admin-dashboard-1">
                <div className="admin-dasboard-1-1">
                <CardView total="4" title = "Total Flights" />
                </div>
                <div className="admin-dasboard-1-2">
                <CardView total = "500" title = "Total Passengers" />
                </div>
                <div className="admin-dasboard-1-3">
                <CardView total = "700" title = "Total Seats" />
                </div>
                <div className="admin-dasboard-1-4">
                <CardView total = "350" title = "Total Bookings" />
                </div>
            </div>
            <div className="admin-dashboard-2">
                 <Paper>
                 <Chart
          data={chartData}
        >
          <ArgumentAxis />
          <ValueAxis max={7} />

          <BarSeries
            valueField="val"
            argumentField="region"
          />
          <Title text="The Categories of Passengers" />
          <Animation />
        </Chart>
      </Paper>
            </div>
            </div>
        )
    }
}
export default AdminDashboard;