import React, { Component } from "react";
import AdminNavBar from "../components/admin-nav-bar";
import AdminDashboard from "./admin-dashboard";
import {Link} from "react-router-dom";
import "./admin-landing-page.scss";
class AdminLandingPage extends Component {
    constructor(props){
        super(props);
        this.state = {
            navBarClass: ''
        };
    }
    onNavBarHandler = (className) => {
        this.setState({
            navBarClass: className
        })
    }
    render(){
        let navClass = `admin-landing-page-1 ${this.state.navBarClass}`;
        return(
            <div >
               <div className="topnav">
                 <Link to=""className="active">Admin</Link>
                 <Link to="/admin/flights">Flights</Link>
                 <Link to ="/">Home</Link>
                </div>
            <div className = "admin-landing-page-2">
            <AdminDashboard />
            </div>
            </div>
        )
    }
}
export default AdminLandingPage;