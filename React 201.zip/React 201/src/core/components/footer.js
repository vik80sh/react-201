import React from "react";
import "./footer.scss";
const Footer = () => {
  return (
    <footer
      className="flex-rw"
      style={{ background: "#fff", color: "#000000" }}
    >
      <ul className="footer-list-top">
        <li>
          <h4 className="footer-list-header">About Star Zet</h4>
        </li>
        <li className="generic-anchor footer-list-anchor">
          Contact-Namita Roy
        </li>
      </ul>
      <ul className="footer-list-top">
        <li id="help">
          <h4 className="footer-list-header">Help</h4>
        </li>
        <li className="generic-anchor footer-list-anchor">Phone-9911223344</li>
      </ul>
      <section className="footer-bottom-section flex-rw">
        <div className="footer-bottom-wrapper">
          <i className="fa fa-copyright"></i>2021 Star Zet, {" "}
          <address className="footer-address">Bangalore</address>
          <span className="footer-bottom-rights">
           
            - All Rights Reserved -@Namita
          </span>
        </div>
        <div className="footer-bottom-wrapper">
         
            Terms | Privacy
        
        </div>
      </section>
    </footer>
  );
};
export default Footer;
