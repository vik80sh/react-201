## Note for the project
> Do `npm start` to run start the react application. Do `npm run xyz` in seperate cmd to run json-server for backend.
> If there is any package dependency failure in case of npm start do npm install
> Once the App is running do login by clicking on the Login Button. Without Login You cant proceed further.Make sure your internet is working properly.


## 1st evaluation comments solution 
> wheelchair or not, travels with infant or not etc. while adding a new passenger: updated code  for admin
> passport, date of birth and address : admin can filter now
> ancillary services : same

## 1st evaluation Others solution: 
> Do `npm run build` for production build, free the port 3000 (No other application should run port 3000 )  Do `serve -s build -l 3000` to run the production code.
> PWA is included for production code .
> SCSS has used with file extension .scss